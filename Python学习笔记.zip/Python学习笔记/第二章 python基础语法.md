# 一. 字面量（常量）

![1729398921986](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729398921986.png)

![1729399473551](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729399473551.png)

# 二. 注释

![1729399632049](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729399632049.png)

![1729399757453](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729399757453.png)

# 三. 变量

![1729400003848](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729400003848.png)

![1729402042796](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729402042796.png)

![1729402073718](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729402073718.png)

# 四. 数据类型

![1729402179487](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729402179487.png)

![1729402197680](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729402197680.png)

# 五. 数据类型转换

![1729405585983](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729405585983.png)

![1729405641798](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729405641798.png)

# 六. 标识符

![1729406376852](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729406376852.png)



![1729406395250](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729406395250.png)

![1729406476266](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729406476266.png)

![1729407118457](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729407118457.png)

# 七. 运算符

![1729407264860](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729407264860.png)

![1729407536526](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729407536526.png)

# 八. 字符串拓展

## 8.1 字符串的三种定义方式

![1729502981559](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729502981559.png)

![1729510080361](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729510080361.png)

![1729510271605](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729510271605.png)



## 8.2 字符串拼接

![1729510324668](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729510324668.png)



## 8.3 字符串格式化

![1729510542385](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729510542385.png)

![1729510851026](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729510851026.png)

![1729510998165](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729510998165.png)



## 8.4 字符串格式化的精度控制

![1729766259627](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729766259627.png)

![1729766472018](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729766472018.png)



## 8.5 字符串格式化方式2（快速格式化）

![1729766630355](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729766630355.png)

![1729766845080](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729766845080.png)

## 8.6 对表达式进行格式化

![1729766991619](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729766991619.png)

![1729767063479](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729767063479.png)

![1729767332188](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729767332188.png)

# 九. 数据输入

![1729768200555](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729768200555.png)

![1729768356445](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729768356445.png)

![1729768584911](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729768584911.png)













