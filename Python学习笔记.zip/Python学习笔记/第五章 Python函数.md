# 一. 函数介绍

![1730287127273](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730287127273.png)

![1730287588273](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730287588273.png)



# 二. 函数的定义

![1730287866705](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730287866705.png)

![1730287944140](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730287944140.png)



# 三. 函数的参数

![1730288016324](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730288016324.png)

![1730288054683](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730288054683.png)

![1730288221689](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730288221689.png)

![1730288321813](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730288321813.png)



# 四. 函数的返回值

![1730295584057](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730295584057.png)

![1730295606058](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730295606058.png)

![1730295784470](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730295784470.png)

![1730295842520](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730295842520.png)

![1730295865151](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730295865151.png)

![1730295957817](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730295957817.png)

![1730296211220](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296211220.png)



# 五. 函数的说明文档

![1730296291367](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296291367.png)

![1730296373381](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296373381.png)

![1730296409336](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296409336.png)

![1730296467807](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296467807.png)



# 六. 函数的嵌套调用

![1730296489237](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296489237.png)

![1730296606615](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296606615.png)



# 七. 变量的作用域

![1730296634836](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296634836.png)

![1730296741309](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296741309.png)

![1730296825845](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296825845.png)

![1730296937770](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296937770.png)

![1730296976227](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730296976227.png)

