# 一. while循环

![1730210205494](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730210205494.png)

![1730210297307](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730210297307.png)



# 二. for循环

## 2.1 基础语法

![1730211149143](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730211149143.png)

![1730211198160](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730211198160.png)

![1730211327268](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730211327268.png)

![1730211370487](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730211370487.png)

![1730211418231](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730211418231.png)



## 2.2 range语句

![1730211676017](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730211676017.png)

![1730211730430](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730211730430.png)

![1730211796156](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730211796156.png)

![1730212057195](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730212057195.png)

![1730280647276](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730280647276.png)

![1730280856904](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730280856904.png)

![1730281083063](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730281083063.png)



