![1730728616843](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730728616843.png)

# 一. json数据格式

![1730728780417](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730728780417.png)

![1730728876863](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730728876863.png)

![1730728961549](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730728961549.png)

![1730729063517](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730729063517.png)

![1730729587733](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730729587733.png)



# 二. pyecharts模块介绍

![1730729606523](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730729606523.png)

pyecharts官方文档：https://05x-docs.pyecharts.org/#/zh-cn/

pyecharts画廊官方文档：https://gallery.pyecharts.org/#/README

![1730730041550](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730730041550.png)



# 三. pyecharts快速入门

## 3.1 构建一个基础的折线图

![1730730199342](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730730199342.png)



## 3.2 使用全局配置项设置属性



# 四. 数据处理



# 五. 创建折线图



