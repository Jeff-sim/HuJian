# 一. 初始对象

![1730975102015](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730975102015.png)

![1730975504332](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730975504332.png)



# 二. 成员方法

![1730975630966](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730975630966.png)

![1730975678688](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730975678688.png)

![1730975758804](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730975758804.png)

![1730975829545](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730975829545.png)

![1730977040825](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730977040825.png)



# 三. 类和对象

![1730977126185](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730977126185.png)

![1730977169395](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730977169395.png)

![1730977224717](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730977224717.png)

![1730977472605](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730977472605.png)



# 四. 构造方法

![1730978758358](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730978758358.png)

![1730979038698](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730979038698.png)

![1730979070250](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730979070250.png)



# 五. 其他内置方法

![1730979137252](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730979137252.png)

## 5.1 字符串方法

![1730979224806](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730979224806.png)

## 5.2 小于（大于）符号比较方法

![1730988603805](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730988603805.png)

## 5.3 小于等于比较符号方法

![1730988727280](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730988727280.png)

## 5.4 比较运算符实现方法

![1730988826078](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730988826078.png)



## 5.5 总结

![1730988946388](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730988946388.png)

# 六. 封装

![1730988988325](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730988988325.png)

![1730989003307](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730989003307.png)

![1730989068653](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730989068653.png)

![1730989098963](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730989098963.png)

![1730989173214](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730989173214.png)

![1730989378360](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730989378360.png)

![1730989530555](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730989530555.png)



# 七. 继承

## 7.1 继承的基础语法

![1731072997622](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731072997622.png)

![1731073101724](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731073101724.png)

![1731073345746](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731073345746.png)

![1731073529789](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731073529789.png)

![1731073826900](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731073826900.png)

![1731073919671](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731073919671.png)

## 7.2 复写和使用父类成员

![1731074076088](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731074076088.png)

![1731074254923](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731074254923.png)

![1731074437775](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731074437775.png)

![1731074528856](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731074528856.png)



# 八. 类型注解

## 8.1 变量的类型注解

![1731074661952](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731074661952.png)

![1731074751737](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731074751737.png)

![1731074940382](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731074940382.png)

![1731075010644](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731075010644.png)

![1731075541712](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731075541712.png)

![1731075627779](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731075627779.png)

![1731075857246](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731075857246.png)

![1731075906392](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731075906392.png)

![1731076046863](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731076046863.png)

![1731076136164](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731076136164.png)

![1731076249944](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731076249944.png)



## 8.2 函数（方法）的类型注解

![1731076742243](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731076742243.png)

![1731076824171](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731076824171.png)

![1731076852725](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731076852725.png)

![1731076903855](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731076903855.png)



## 8.3 Union类型

![1731119440014](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731119440014.png)

![1731119637177](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731119637177.png)



# 九. 多态

![1731119787185](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731119787185.png)

![1731119811832](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731119811832.png)

![1731119902474](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731119902474.png)

![1731119946979](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731119946979.png)

![1731120053470](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731120053470.png)

![1731120247844](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1731120247844.png)





