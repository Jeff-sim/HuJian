一. 数据容器入门

![1730297312738](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730297312738.png)

![1730297364522](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730297364522.png)

![1730297410137](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730297410137.png)



# 二. 数据容器：list（列表）

## 2.1 列表的定义



![1730380304505](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730380304505.png)

![1730380388319](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730380388319.png)

![1730380504880](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730380504880.png)

![1730380710850](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730380710850.png)

## 2.2 列表的索引

![1730380802729](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730380802729.png)

![1730380893358](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730380893358.png)

![1730380958198](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730380958198.png)

![1730381871212](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730381871212.png)

## 2.3 列表的常用操作

![1730427415490](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730427415490.png)

![1730427514542](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730427514542.png)

![1730427566298](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730427566298.png)

![1730427712146](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730427712146.png)

![1730427870072](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730427870072.png)

![1730427972853](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730427972853.png)

![1730428031803](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730428031803.png)

![1730428302950](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730428302950.png)

![1730428717687](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730428717687.png)

![1730428784952](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730428784952.png)

![1730428875824](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730428875824.png)

![1730428935079](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730428935079.png)



# 三. list列表的遍历

## 3.1 while循环遍历列表

![1730429074914](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730429074914.png)



## 3.2 for循环遍历列表

![1730429593057](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730429593057.png)

![1730429758723](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730429758723.png)

![1730429816010](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730429816010.png)



# 四. 数据容器：tuple（元组）



![1730429885034](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730429885034.png)

![1730430141396](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730430141396.png)

![1730430321931](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730430321931.png)

![1730623472004](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730623472004.png)

![1730623560311](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730623560311.png)

![1730623597514](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730623597514.png)



# 五. 数据容器：str（字符串）

![1730623753670](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730623753670.png)

![1730623861058](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730623861058.png)

![1730624002502](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730624002502.png)

![1730624173280](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730624173280.png)

![1730624366633](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730624366633.png)

![1730624401508](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730624401508.png)



# 六. 数据容器（序列）的切片

![1730624462430](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730624462430.png)

![1730624510927](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730624510927.png)

![1730624950799](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730624950799.png)



# 七. 数据容器：set（集合）

![1730625045552](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730625045552.png)

## 7.1 集合的定义（不允许重复且乱序）

![1730625090613](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730625090613.png)

## 7.2 集合的常用操作

### 7.2.1 添加新元素：add方法

![1730625307431](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730625307431.png)

### 7.2.2 移出元素：remove方法

![1730625449470](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730625449470.png)

### 7.2.3 从集合中随机取出一个元素：pop方法

![1730625548575](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730625548575.png)

### 7.2.4 清空集合：clear方法

![1730625654970](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730625654970.png)

### 7.2.5 取出两个集合的差集：difference方法

![1730625707069](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730625707069.png)

### 7.2.6 消除两个集合的差集：difference_update方法

![1730625839096](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730625839096.png)



### 7.2.7 两个集合合并：union方法

![1730625937287](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730625937287.png)

### 7.2.8 统计集合的元素数量：len函数



## 7.3 集合的遍历（集合不支持索引，不能用while循环遍历）

![1730626366776](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730626366776.png)

![1730626397874](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730626397874.png)





# 八. 数据容器：dict（字典、映射）

## 8.1 字典的定义

![1730642282369](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730642282369.png)

![1730642353639](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730642353639.png)

![1730642409819](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730642409819.png)

![1730642778945](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730642778945.png)

![1730642941097](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730642941097.png)

![1730643291619](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730643291619.png)

## 8.2 字典的常用操作

![1730689032981](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689032981.png)

![1730689218088](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689218088.png)

![1730689400974](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689400974.png)

![1730689622715](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689622715.png)

![1730689649285](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689649285.png)



## 8.3 字典的两种遍历方式

![1730689547550](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689547550.png)

# 九. 数据容器的总结对比

![1730689771053](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689771053.png)

![1730689798863](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689798863.png)

![1730689860280](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689860280.png)



# 十. 数据容器的通用操作

![1730689923125](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689923125.png)

![1730689957921](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730689957921.png)

![1730690089343](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730690089343.png)

![1730690406629](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730690406629.png)

![1730690594177](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730690594177.png)

​		sorted函数默认是升序排序，排序结果放入一个列表中。如果像降序排序，加一个参数：reverse=True

![1730690618977](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730690618977.png)

# 十一. 字符串大小比较

![1730690802646](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730690802646.png)

![1730690922819](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730690922819.png)







