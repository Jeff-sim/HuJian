# 一. 文件的编码

![1730708538293](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730708538293.png)

![1730708613314](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730708613314.png)

![1730708647705](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730708647705.png)

![1730708685982](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730708685982.png)

![1730708744669](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730708744669.png)



# 二. 文件的读取

![1730708855743](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730708855743.png)

![1730708882069](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730708882069.png)

![1730708907154](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730708907154.png)

![1730709007129](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730709007129.png)

![1730709044532](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730709044532.png)

## 2.1 read方法读取文件



![1730709267174](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730709267174.png)

![1730709631225](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730709631225.png)

## 2.2 for循环读取文件

![1730709776993](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730709776993.png)

![1730709816241](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730709816241.png)

## 2.3 关闭文件：close方法



![1730709886627](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730709886627.png)

![1730710023915](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730710023915.png)

![1730710143024](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730710143024.png)

![1730710230297](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730710230297.png)

![1730710249044](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730710249044.png)



# 三. 文件的写入

![1730710356232](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730710356232.png)

​		当模式是"w"，即写入时：若文件不存在则创建文件；若文件已存在且里面有内容，则用新内容覆盖原来的内容。如果想保留原来的内容并在后面接着写入新内容，则必须使用"a"，即追加模式

![1730712260919](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730712260919.png)



# 四. 文件的追加

![1730719515538](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730719515538.png)

![1730719549641](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730719549641.png)

![1730719677521](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730719677521.png)







