# 一. Python异常

![1730719828171](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730719828171.png)

![1730719924082](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730719924082.png)

![1730719995562](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730719995562.png)



# 二. 异常的捕获方法

![1730720951943](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730720951943.png)

![1730721018027](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730721018027.png)

## 2.1 捕获常规异常

![1730721055051](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730721055051.png)

## 2.2 捕获指定异常

![1730721288862](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730721288862.png)

## 2.3 捕获多个异常

![1730721457135](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730721457135.png)

## 2.4 捕获所有的异常

![1730721595329](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730721595329.png)







![1730721784131](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730721784131.png)

![1730721843474](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730721843474.png)

 ![1730722090818](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730722090818.png)

# 三. 异常的传递

![1730722466237](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730722466237.png)



# 四. Python模块

## 4.1 模块的导入

![1730722723992](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730722723992.png)

![1730722766939](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730722766939.png)

![1730723119755](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730723119755.png)

![1730723401409](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730723401409.png)

![1730723530882](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730723530882.png)

![1730723636110](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730723636110.png)

![1730723849817](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730723849817.png)



## 4.2 自定义模块

![1730723875401](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730723875401.png)

![1730724047238](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730724047238.png)

![1730724410865](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730724410865.png)

![1730724660120](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730724660120.png)

![1730724813239](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730724813239.png)



# 五. Python包

## 5.1 自定义包

![1730724887586](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730724887586.png)

![1730724952349](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730724952349.png)

![1730724986110](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730724986110.png)

![1730725097141](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730725097141.png)

![1730727139408](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730727139408.png)

![1730727280554](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730727280554.png)



## 5.2 安装第三方包

![1730727302253](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730727302253.png)

![1730727350470](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730727350470.png)

![1730728109688](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730728109688.png)

![1730728230191](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730728230191.png)

![1730728482708](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730728482708.png)



