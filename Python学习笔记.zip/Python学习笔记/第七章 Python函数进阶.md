# 一. 函数多返回值

![1730691179424](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730691179424.png)

![1730691222709](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730691222709.png)

![1730691259373](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730691259373.png)



# 二. 函数多种传参方式

## 2.1 位置参数

![1730701586246](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730701586246.png)



## 2.2 关键字参数

![1730701701571](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730701701571.png)



## 2.3 缺省参数

![1730702005595](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730702005595.png)



## 2.4 不定长参数

![1730702150412](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730702150412.png)

### 2.4.1 位置传递不定长

![1730702187545](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730702187545.png)

### 2.4.2 关键字传递不定长

![1730702319981](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730702319981.png)

![1730702585258](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730702585258.png)



# 三. 匿名函数

## 3.1 函数作为参数传递

![1730702660269](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730702660269.png)

![1730702904554](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730702904554.png)

![1730703084570](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730703084570.png)



## 3.2 lambda匿名函数

![1730703137723](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730703137723.png)

![1730703237431](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730703237431.png)

![1730703450536](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730703450536.png)



