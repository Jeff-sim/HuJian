# 一. 布尔类型和比较运算符

![1729768883591](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729768883591.png)

![1729768946960](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729768946960.png)

![1729768992651](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729768992651.png)

![1729769027136](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729769027136.png)

![1729769446501](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729769446501.png)



# 二. if语句的基本格式

![1729769513506](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729769513506.png)

![1729769843894](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729769843894.png)



# 三. if else语句

![1729769948307](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729769948307.png)

![1729769972760](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729769972760.png)

![1729770111864](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729770111864.png)

![1729770158094](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729770158094.png)



# 四. if elif else语句

![1729778105089](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729778105089.png)

![1729778140655](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1729778140655.png)

![1730008407690](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730008407690.png)



# 五. 判断语句的嵌套

![1730008996147](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730008996147.png)

![1730009611537](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1730009611537.png)

