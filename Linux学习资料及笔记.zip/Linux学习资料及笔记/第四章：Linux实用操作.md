# 1. 各类小技巧（快捷键）

![1738156659907](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738156659907.png)

![1738156731368](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738156731368.png)

![1738156817544](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738156817544.png)

![1738156881363](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738156881363.png)

![1738157005261](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738157005261.png)

![1738157161713](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738157161713.png)

![1738157295576](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738157295576.png)

![1738157339107](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738157339107.png)



# 2. 软件安装

![1738157403669](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738157403669.png)

![1738157414207](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738157414207.png)

![1738157502168](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738157502168.png)

![1738157634631](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738157634631.png)

![1738158728771](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738158728771.png)

![1738158783362](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738158783362.png)

![1738158898487](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738158898487.png)



# 3. systemctl

![1738158938869](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738158938869.png)

![1738159266581](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738159266581.png)

![1738159283878](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738159283878.png)



# 4. 软连接

![1738159330504](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738159330504.png)

![1738159629954](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738159629954.png)



# 5. 日期、时区

![1738159667099](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738159667099.png)

![1738159686256](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738159686256.png)

![1738159755053](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738159755053.png)

![1738159923515](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738159923515.png)

![1738160065877](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738160065877.png)

![1738160155267](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738160155267.png)

![1738160197457](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738160197457.png)

![1738160293654](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738160293654.png)

![1738160518650](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738160518650.png)



# 6. IP地址、主机名

## 6.1 IP地址和主机名

![1738161010340](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738161010340.png)

![1738161020074](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738161020074.png)

![1738161131952](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738161131952.png)

![1738161216163](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738161216163.png)

![1738161282842](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738161282842.png)

![1738161493270](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738161493270.png)

![1738161502546](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738161502546.png)

![1738161678566](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738161678566.png)

![1738162039265](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738162039265.png)



## 6.2 虚拟机配置固定IP

![1738162125874](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738162125874.png)

![1738162143178](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738162143178.png)

![1738162208484](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738162208484.png)

![1738162814843](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738162814843.png)



# 7. 网络传输

## 7.1 下载和网络请求

![1738233569178](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738233569178.png)

![1738233597947](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738233597947.png)

![1738233747045](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738233747045.png)

![1738233915919](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738233915919.png)

![1738234019347](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738234019347.png)

![1738234056927](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738234056927.png)



## 7.2 端口

![1738234114252](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738234114252.png)

![1738234124400](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738234124400.png)

![1738234281809](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738234281809.png)

![1738234290618](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738234290618.png)

![1738234427929](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738234427929.png)

![1738234820927](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738234820927.png)

![1738235077413](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738235077413.png)



# 8. 进程管理

![1738235191946](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738235191946.png)

![1738235237485](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738235237485.png)

![1738235562188](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738235562188.png)

![1738235582363](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738235582363.png)

![1738235754669](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738235754669.png)

![1738235770705](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738235770705.png)



# 9. 主机状态

![1738235800949](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738235800949.png)

## 9.1 系统资源监控top命令

![1738235852006](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738235852006.png)

![1738236136662](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738236136662.png)

![1738236342114](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738236342114.png)

![1738236455205](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738236455205.png)

![1738236669062](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738236669062.png)



## 9.2 磁盘监控

![1738236850645](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738236850645.png)

![1738243125804](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243125804.png)

![1738243257501](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243257501.png)



## 9.3 网络监控

![1738243351542](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243351542.png)

![1738243471671](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243471671.png)



# 10. 环境变量

![1738243530846](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243530846.png)

![1738243577793](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243577793.png)

![1738243585775](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243585775.png)

![1738243632111](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243632111.png)

![1738243704845](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243704845.png)

![1738243762357](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243762357.png)

![1738243851498](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243851498.png)

![1738243902259](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738243902259.png)

![1738244180156](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738244180156.png)

![1738244494981](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738244494981.png)

![1738244643803](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738244643803.png)



# 11. 上传、下载

![1738244753901](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738244753901.png)

![1738244811079](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738244811079.png)

![1738245021375](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738245021375.png)

![1738245214401](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738245214401.png)



# 12. 压缩、解压

![1738245241249](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738245241249.png)

![1738245262342](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738245262342.png)

![1738245320439](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738245320439.png)

![1738245476246](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738245476246.png)

![1738245970984](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738245970984.png)

![1738246350696](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738246350696.png)

![1738246493827](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738246493827.png)

![1738246680385](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738246680385.png)

