# 1. 认知root用户

![1738147174568](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738147174568.png)

![1738147257863](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738147257863.png)

![1738147293579](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738147293579.png)

![1738147449448](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738147449448.png)

![1738147523234](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738147523234.png)

![1738147959188](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738147959188.png)



# 2. 用户、用户组管理

![1738148024599](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738148024599.png)

![1738148083792](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738148083792.png)

![1738148175122](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738148175122.png)

![1738148467479](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738148467479.png)

![1738148640480](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738148640480.png)

![1738148701833](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738148701833.png)

![1738148738432](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738148738432.png)



# 3. 查看权限控制

![1738148801075](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738148801075.png)

![1738148885912](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738148885912.png)

![1738149063834](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738149063834.png)

![1738149402812](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738149402812.png)



# 4. 修改权限控制 - chmod

![1738149905199](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738149905199.png)

![1738149936604](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738149936604.png)

![1738150351122](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738150351122.png)

![1738150366713](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738150366713.png)



# 5. 修改权限控制 - chown

![1738150450408](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738150450408.png)

![1738150820117](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738150820117.png)

