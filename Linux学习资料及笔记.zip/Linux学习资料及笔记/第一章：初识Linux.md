# 一. 操作系统概述



# 二. 初识Linux

![1736087908922](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1736087908922.png)

![1737960416531](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737960416531.png)

![1736088086970](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1736088086970.png)

![1737960560753](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737960560753.png)



# 三. 虚拟机介绍

![1736169440473](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1736169440473.png)



# 四. VMware安装

![1737960870581](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737960870581.png)



# 五. 远程连接Linux系统

![1736338243701](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1736338243701.png)

![1736338412549](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1736338412549.png)

![1736338514011](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1736338514011.png)

![1737962231102](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737962231102.png)

![1737962262399](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737962262399.png)

# 六. win10配置WSL

![1737962387082](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737962387082.png)

![1737962484513](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737962484513.png)

![1737962547693](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737962547693.png)

![1737962638380](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737962638380.png)

# 七. 虚拟机快照

![1737964143736](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737964143736.png)

![1737964222568](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737964222568.png)

![1737964656694](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737964656694.png)

