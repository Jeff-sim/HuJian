# 1. Linux目录结构

![1737964936678](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737964936678.png)

![1737973285451](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737973285451.png)

![1737973312982](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737973312982.png)

![1737973425595](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737973425595.png)



# 2. Linux命令入门

## 2.1 Linux命令基础

![1737973522922](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737973522922.png)

![1737973616658](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737973616658.png)

![1737973859725](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737973859725.png)



## 2.2 ls命令入门

![1737973920233](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737973920233.png)

![1737974101343](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974101343.png)

![1737974230741](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974230741.png)



## 2.3 ls命令的参数和选项

![1737974289916](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974289916.png)

![1737974372452](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974372452.png)

![1737974434139](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974434139.png)

![1737974503294](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974503294.png)

![1737974552827](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974552827.png)

![1737974603738](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974603738.png)

![1737974674322](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974674322.png)



# 3. 目录切换相关命令（cd/pwd）

![1737974853543](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737974853543.png)

![1737975004855](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737975004855.png)

![1737975120268](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737975120268.png)



# 4. 相对路径、绝对路径和特殊路径符

![1737975328483](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737975328483.png)

![1737975372777](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737975372777.png)

![1737975874872](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737975874872.png)

![1737976030634](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737976030634.png)



# 5. 创建目录命令（mkdir）

![1737976196504](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737976196504.png)

![1737976494931](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737976494931.png)

![1737976569247](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737976569247.png)



# 6. 文件操作命令（touch、cat、more、cp、mv）

![1737976829239](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737976829239.png)

![1737976900515](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737976900515.png)

![1737977002345](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737977002345.png)

![1737977051942](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737977051942.png)

![1737977196214](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737977196214.png)

![1737977391673](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737977391673.png)

![1737977433695](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737977433695.png)

![1737977546768](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737977546768.png)

![1737978197565](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737978197565.png)

![1737978389264](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737978389264.png)

![1737978598049](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737978598049.png)

![1737978666843](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737978666843.png)

![1737978678253](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737978678253.png)



# 7. 查找命令（which、find）

![1737978726875](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737978726875.png)

![1737978841538](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737978841538.png)

![1737984057072](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737984057072.png)

![1737984189735](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737984189735.png)

![1737984472854](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737984472854.png)

![1737984610722](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737984610722.png)



# 8. grep、wc和管道符

![1737984695663](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737984695663.png)

![1737985079211](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737985079211.png)

![1737985111421](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737985111421.png)

![1737985333633](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737985333633.png)

==wc什么选项都不加，返回：文件行数、文件单词数、文件大小、文件名称==

![1737985394307](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737985394307.png)

![1737985537376](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737985537376.png)

![1737986047291](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737986047291.png)

![1737986275379](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1737986275379.png)



# 9. echo和重定向符

![1738140391140](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738140391140.png)

![1738140493325](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738140493325.png)

![1738140611922](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738140611922.png)

![1738140740591](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738140740591.png)

![1738140776761](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738140776761.png)

![1738140839801](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738140839801.png)

![1738140888780](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738140888780.png)

![1738141044744](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738141044744.png)

==ctrl+C：退出tail -f连续跟踪模式==

![1738141212931](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738141212931.png)

![1738141503921](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738141503921.png)

# 10. vi编辑器

![1738141537540](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738141537540.png)

![1738141624735](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738141624735.png)

![1738141731006](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738141731006.png)

![1738141779877](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738141779877.png)

![1738142040268](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738142040268.png)

![1738142216872](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738142216872.png)

![1738142407759](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738142407759.png)

![1738142813295](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738142813295.png)

![1738142986059](C:\Users\胡建\AppData\Roaming\Typora\typora-user-images\1738142986059.png)







