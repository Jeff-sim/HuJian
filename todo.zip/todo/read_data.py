
# 打开文件
f = open("test1.txt","r", encoding="utf-8")
print(type(f))
# 1.读取文件，read
# print(f"读取10个字节的结果是：{f.read(10)}")
# print(f"读取文件全部内容的结果是：{f.read()}")
# print("------------------------------------------------------")
# 2.读取文件， readLines：读取文件的全部行，封装到一个列表中
# lines = f.readlines()
# print(f"lines对象的类型：{type(lines)}")
# print(f"lines对象的内容：{lines}")
# print("------------------------------------------------------")
# 3.读取文件，readline：一次读取一行内容
# for line in open("test1.txt","r", encoding="utf-8"):
#     print(line)
#
# f.close()

# 4. with open操作：通过在with Open的语句块中对文件进行操作，在操作完成后自动关闭文件，避免忘记关闭文件
with open("test1.txt","r", encoding="utf-8") as f:
    for line in open("test1.txt", "r", encoding="utf-8"):
        print(line)


